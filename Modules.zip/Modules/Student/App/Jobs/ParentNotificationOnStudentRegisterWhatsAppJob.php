<?php

namespace Modules\Student\App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Modules\Common\Helpers\WhatsAppService;

class ParentNotificationOnStudentRegisterWhatsAppJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $student;
    private $schoolSettings;
    private $password;
    private $link;
    /**
     * Create a new job instance.
     */
    public function __construct($student, $schoolSettings, $password)
    {
        $this->student = $student;
        $this->schoolSettings = $schoolSettings;
        $this->password = $password;
        $this->link = 'https://alaafaqschool.com/login';
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $parent_phone = $this->student->parent_phone;
        $whatsAppService = new WhatsAppService($this->schoolSettings);
        $message =
            "عزيزنا ولي أمر الطالب: {$this->student->name}\n" .
            "تم تسجيل ابنكم في المدرسة بنجاح.\n" .
            "رقم الهوية: {$this->student->identity_number}\n" .
            "كلمة المرور: {$this->password}\n" .
            "رابط الدخول: {$this->link}\n\n" .
            "Dear parent of student: {$this->student->name}\n" .
            "Your child has been successfully registered at the school.\n" .
            "Identity Number: {$this->student->identity_number}\n" .
            "Password: {$this->password}\n" .
            "Login Link: {$this->link}";
        $whatsAppService->sendMessage($parent_phone, $message);
    }
}
