<?php

return [
    'name' => 'Employee',
];
