<?php

return [
    'name' => 'Salary',
];
