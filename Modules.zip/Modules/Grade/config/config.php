<?php

return [
    'name' => 'Grade',
];
